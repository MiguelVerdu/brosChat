CREATE TABLE IF NOT EXISTS USUARIO(
   idUsuario INTEGER PRIMARY KEY AUTOINCREMENT,
   nombre    varchar(100) not null,
   apellidos varchar(100) NOT NULL,
   alias	 varCHAR(100) not null,
   telefono  VARCHAR(20) not null,
   foto 	 varchar(300) not null
);

create TABLE IF NOT EXISTS contactos(
  idUsuario1 INTEGER,
  idUsuario2 integer,
  constraint PK_contactos primary key(idUsuario1, idUsuario2),
  constraint FK_usuario1 foreign key(idUsuario1) references usuario(idUsuario),
  constraint FK_usuario2 foreign key(idUsuario2) references usuario(idUsuario)
  );
  
  create TABLE IF NOT EXISTS publicacion(
  idPublicacion integer,
  idUsuario INTEGER,
  texto varchar(100) not null,
  titulo varchar(200) not null,
  fechaCompleta datetime not null,
  constraint PK_publicacion primary key(idPublicacion, idUsuario)
  constraint FK_usuario foreign key(idUsuario) references usuario(idUsuario)
  );
  
  create TABLE IF NOT EXISTS chat(
  idChat INTEGER,
  idPublicacion integer,
  idUsuarioPublicacion integer, 
  idUsuarioPregunta integer,
  constraint PK_chat primary key(idPublicacion, idChat, idUsuarioPublicacion),
  constraint FK_publicacion foreign key(idPublicacion, idUsuarioPublicacion) references publicacion(idPublicacion, idUsuario),
  constraint FK_usuario_pregunta foreign key(idUsuarioPregunta) references usuario(idUsuario) 
  );
  
  create TABLE IF NOT EXISTS mensaje(
	idMensaje integer,
  	idChat integer,
  	texto text,
  	fechaCompleta datetime,
  	constraint PK_mensaje primary key(idMensaje, idChat),
  	constraint FK_chat foreign key(idChat) references chat(idChat)
);