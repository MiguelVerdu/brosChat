// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
var db = null;
var script = null;

function myFunction(){
	jQuery.get("js/script.sql", function(txt){
		script = txt;
		//$("#txt").text(txt);
	});
}

var example = angular.module('starter', ['ionic', 'ngCordova'])
    .run(function($ionicPlatform, $cordovaSQLite) {
        $ionicPlatform.ready(function() {
            if(window.cordova && window.cordova.plugins.Keyboard) {
                cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
            }
            if(window.StatusBar) {
                StatusBar.styleDefault();
            }
            //db = $cordovaSQLite.openDB({ name: 'my.db' });
            db = window.sqlitePlugin.openDatabase({name: "mySQLite.db", location: 'default'});
			//script = "CREATE TABLE IF NOT EXISTS usuario (id integer primary key, firstname text, lastname text)";
			jQuery.get("js/script.sql", function(txt){
				script = txt;
				$("#txt").text(txt);
			});
			if(script != null){
				$cordovaSQLite.execute(db, script);
			}else{
				alert("error");
			}

        });
    });

var aux;

example.controller("ExampleController", function($scope, $cordovaSQLite) {

    $scope.insert = function(firstname, lastname, alias, telefono, foto) {
        var query = "INSERT INTO usuario (nombre, apellidos, alias, telefono, foto) VALUES (?,?,?,?,?)";
        $cordovaSQLite.execute(db, query, [firstname, lastname, alias, telefono, foto]).then(function(res) {
            console.log("INSERT ID -> " + res.insertId);
        }, function (err) {
            console.error(err);
            alert(err.message);
        });
    }

    $scope.select = function(lastname) {
        var query = "SELECT nombre, apellidos FROM usuario WHERE apellidos = ?";
        $cordovaSQLite.execute(db, query, [lastname]).then(function(res) {
            if(res.rows.length > 0) {
                console.log("SELECTED -> " + res.rows.item(0).nombre + " " + res.rows.item(0).apellidos);
                document.getElementById("prueba").innerHTML = "SELECTED -> " + res.rows.item(0).nombre + " " + res.rows.item(0).apellidos;
                aux = "SELECTED -> " + res.rows.item(0).nombre + " " + res.rows.item(0).apellidos;
                alert(aux);
                //var elemento = document.getElementById("txt");
				//alert(elemento.innerHTML)
            } else {
                console.log("No results found");
                document.getElementById("prueba").innerHTML = "No resultados encontrados";
            }
        }, function (err) {
            console.error(err);
        });
    }
});